package com.example.beckend.Controller;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.SneakyThrows;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

@RestController
@CrossOrigin
@RequestMapping("/file")

public class FileController {
@PostMapping
    public String saveFile(@RequestParam MultipartFile file) throws IOException {
    String s = UUID.randomUUID() + file.getOriginalFilename();
    FileOutputStream fileOutputStream = new FileOutputStream("src/main/resources/"+s );
    fileOutputStream.write(file.getBytes());
    fileOutputStream.close();
return s;
}
@SneakyThrows
@GetMapping("/{name}")
    public void getFile(@PathVariable String  name, HttpServletResponse response){
    FileInputStream fileInputStream = new FileInputStream("src/main/resources/" + name);
    ServletOutputStream outputStream = response.getOutputStream();
    fileInputStream.transferTo(outputStream);
    outputStream.close();
    fileInputStream.close();
}
}

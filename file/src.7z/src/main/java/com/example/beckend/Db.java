package com.example.beckend;

import com.example.beckend.Entity.User;

import java.util.ArrayList;
import java.util.List;

public class Db {
    public static ArrayList<User>users=new ArrayList<User>();
    public static void getUser(){
        users.addAll(List.of(
                new User(User.lastId++,"Shohjahon","Sharipov",16,"a.png")
        ));
    }
}

package com.example.beckend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeckendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeckendApplication.class, args);
	}

}
